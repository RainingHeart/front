from django.apps import AppConfig


class DemandsConfig(AppConfig):
    name = 'demands'
